"test"
"\"hi hi\""
"hi" "hi"
"hi\n"
"hi\t"
"hi\"
int x;
/* test test */
int y;
/*  hia;lsdkfjal;sdkfj************l;sdfja;lsdfjk*************/
'c'
''
'\n'
''
''
auto
break
case
char
const
continue
default
do
double
else
enum
extern
float
for
goto
if
int
long
register
return
short
signed
sizeof
static
struct
switch
typedef
union
unsigned
void
volatile
while

doubley
{}
()
[]
++
+
&&
&
&&
